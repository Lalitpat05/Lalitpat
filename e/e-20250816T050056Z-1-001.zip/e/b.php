<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>วณิชชา สดใส (มายด์มิ้นท์)</title>
</head>

<body>
<h1>วณิชชา สดใส (มายด์มิ้นท์)</h1>

<?php
	$a=10;
	$b=5;
	$c=$a+($b*2);
	echo $c;
?>

</body>
</html>