<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>วณิชชา สดใส (มายด์มิ้นท์)</title>
</head>

<body>
<h1>วณิชชา สดใส (มายด์มิ้นท์)-- do while</h1>
	
<?php
$b=1;
do{
	echo $b. "วณิชชา สดใส (มายด์มิ้นท์)<br>" ;
	echo"<img src='2.jpg' width='100'><hr>";
	$b++;
} while($b <= 10) ;
?>

</body>
</html>