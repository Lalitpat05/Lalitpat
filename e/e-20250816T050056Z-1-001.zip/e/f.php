<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>วณิชชา สดใส (มายด์มิ้นท์)</title>
</head>

<body>
<h1>วณิชชา สดใส (มายด์มิ้นท์)--for</h1>
	
<?php
	for ($b=1; $b<=10; $b++) {
	echo $b. "วณิชชา สดใส (มายด์มิ้นท์)<br>" ;
	echo"<img src='2.jpg' width='100'><hr>";
}
?>

</body>
</html>