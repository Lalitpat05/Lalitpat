<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>วณิชชา สดใส (มายด์มิ้นท์)</title>
</head>

<body>
<h1>วณิชชา สดใส (มายด์มิ้นท์)</h1>
<!--<h1>วณิชชา สดใส (มายด์มิ้นท์)</h1>-->

<script>
	document.write("Web Programming");
</script>

<?php
	#echo"มหาวิทยาลัยมหาสารคาม <br>";
	//print"MSU <br>";
	echo"<br>มหาวิทยาลัยมหาสารคาม <br>";
	print"<br>MSU <br>";
	
	
	$name = "Wanitcha Sodsai";
	$age = 25.5;
	echo $name."<br>";
	
	echo gettype($age)."<br>";
	var_dump($name);
	
	
?>



</body>
</html>